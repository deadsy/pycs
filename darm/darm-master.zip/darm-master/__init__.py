"""Simple Python init script to allow inclusion of this entire directory."""
from darm import Darm, disasm_armv7, disasm_thumb, disasm_thumb2
